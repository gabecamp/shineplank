Project folder:

USB_MSD_Device_bootloader_v1.0\Source\Device\app\msd_bootloader\cw10\kinetis_k20d7